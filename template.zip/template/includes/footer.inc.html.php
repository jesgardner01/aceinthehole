<footer>
    <div class="footernav">
        <a href="<?php echo BASE_URL; ?>"class="active">About Ace</a>
        <a href="<?php echo BASE_URL; ?>details.html">Course Details</a>
        <a href="<?php echo BASE_URL; ?>faq.html">FAQ</a>
        <a href="<?php echo BASE_URL; ?>registration.html"> Registration</a>
        <a href="<?php echo BASE_URL; ?>contact.html"> Contact Us</a>
    </div>
    <p>Copyright &copy; Ace in the Hole<br>
        <a href="mailto:hello@paceinthehole.com">hello@portlandhistoricaltours.com</a>
        <?php echo date('Y'); ?></p>
</footer>