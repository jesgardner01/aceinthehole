<nav>
    <div class="topnav" id="myTopnav">

        <a href="<?php echo BASE_URL; ?>"class="active">About Ace</a>
        <a href="<?php echo BASE_URL; ?>details.html">Course Details</a>
        <a href="<?php echo BASE_URL; ?>faq.html">FAQ</a>
        <a href="<?php echo BASE_URL; ?>registration.html"> Registration</a>
        <a href="<?php echo BASE_URL; ?>contact.html"> Contact Us</a>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <i class="fa fa-bars"></i>
        </a>
    </div>
</nav>